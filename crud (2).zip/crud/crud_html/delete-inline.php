<?php

$stu_id = $_GET['id'];

    /* for connection */
    $conn = mysqli_connect("localhost","root","","crud") or die("connection failed");

    /* for query */
    $sql = "DELETE FROM student  WHERE sid = {$stu_id}";

    $result = mysqli_query($conn,$sql) or die("Query Unsuccessfull."); 

    header("LOCATION: http://localhost/crud/crud_html/index.php");

    mysqli_close($conn);
?>